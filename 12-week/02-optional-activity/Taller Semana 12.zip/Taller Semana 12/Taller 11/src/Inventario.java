import java.util.HashMap;
import java.util.Map;

public class Inventario {

    private Map<String, Producto> productos;

    private Map<String, Integer> cantidades;

    public Inventario() {

        productos = new HashMap<>();
        cantidades = new HashMap<>();
    }

    public void agregarProducto(Producto p) {

        if (productos.containsKey(p.getCodigo())) {
            System.out.println("Error: ya existe un producto con ese código.");
            return;
        }

        productos.put(p.getCodigo(), p);

        cantidades.put(p.getCodigo(), 0);

        System.out.println("Producto agregado correctamente.");
    }

    public void entrada(String codigo, int cantidad) {

        if (!productos.containsKey(codigo)) {
            System.out.println("Error: el código no existe.");
            return;
        }

        int stockActual = cantidades.get(codigo);

        cantidades.put(codigo, stockActual + cantidad);

        System.out.println("Entrada registrada correctamente.");
    }

    public void salida(String codigo, int cantidad) {

        if (!productos.containsKey(codigo)) {
            System.out.println("Error: el código no existe.");
            return;
        }

        int stockActual = cantidades.get(codigo);

        if (cantidad > stockActual) {
            System.out.println("Error: stock insuficiente.");
            return;
        }

        cantidades.put(codigo, stockActual - cantidad);

        System.out.println("Salida registrada correctamente.");
    }

    public Producto buscar(String codigo) {

        if (!productos.containsKey(codigo)) {
            return null;
        }

        return productos.get(codigo);
    }

    public void listar() {

        System.out.println("\n===== INVENTARIO =====");

        for (Map.Entry<String, Producto> entry : productos.entrySet()) {

            String codigo = entry.getKey();

            Producto producto = entry.getValue();

            int stock = cantidades.get(codigo);

            System.out.println(producto + " | Stock: " + stock);
        }
    }
}