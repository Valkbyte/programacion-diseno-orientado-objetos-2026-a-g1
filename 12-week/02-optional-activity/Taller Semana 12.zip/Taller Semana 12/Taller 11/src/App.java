public class App {

    public static void main(String[] args) {

        Inventario inventario = new Inventario();

        try {

            Producto p1 = new Producto("01", "Sensor de humedad", 45000);
            Producto p2 = new Producto("02", "Servo motor", 78000);
            Producto p3 = new Producto("03", "Arduino Uno", 120000);
            Producto p4 = new Producto("04", "Pantalla LCD", 65000);

            inventario.agregarProducto(p1);
            inventario.agregarProducto(p2);
            inventario.agregarProducto(p3);
            inventario.agregarProducto(p4);

            inventario.agregarProducto(p1);

            inventario.entrada("01", 10);
            inventario.entrada("02", 5);
            inventario.entrada("03", 8);

            inventario.salida("01", 3);
            inventario.salida("02", 10);

            inventario.entrada("10", 4);

            Producto encontrado = inventario.buscar("03");

            if (encontrado != null) {
                System.out.println("\nProducto encontrado:");
                System.out.println(encontrado);
            } else {
                System.out.println("Producto no encontrado.");
            }
            inventario.listar();

        } catch (IllegalArgumentException e) {

            System.out.println("Error en los datos: " + e.getMessage());
        }

        System.out.println("\nPrograma finalizado correctamente :D");
    }
}