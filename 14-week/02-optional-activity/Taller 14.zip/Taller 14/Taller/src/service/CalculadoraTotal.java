package service;

import model.TipoCliente;

public class CalculadoraTotal {
    private static final double IVA = 0.19;

    public double calcularTotal(double subtotal, boolean aplicarDescuento, TipoCliente tipoCliente) {
        if (subtotal <= 0) {
            return 0;
        }

        double total = subtotal;

        if (aplicarDescuento) {
            total -= total * tipoCliente.getDescuento();
        }

        total += total * IVA;
        return Math.round(total * 100.0) / 100.0;
    }
}