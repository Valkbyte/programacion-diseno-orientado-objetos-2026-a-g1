package app;

import model.TipoCliente;
import service.CalculadoraTotal;

public class AppRefactor {
    public static void main(String[] args) {
        double subtotal = 500000;
        boolean aplicarIVA = true;
        boolean aplicarDescuento = true;
        TipoCliente tipoCliente = TipoCliente.VIP;

        CalculadoraTotal calculadora = new CalculadoraTotal();
        double total = calculadora.calcularTotal(subtotal, aplicarDescuento, tipoCliente);

        System.out.println("Total: " + total);
    }
}
