package model;

public enum TipoCliente {
    NORMAL(0.05),
    FRECUENTE(0.10),
    VIP(0.20);

    private final double descuento;

    TipoCliente(double descuento) {
        this.descuento = descuento;
    }

    public double getDescuento() {
        return descuento;
    }
}