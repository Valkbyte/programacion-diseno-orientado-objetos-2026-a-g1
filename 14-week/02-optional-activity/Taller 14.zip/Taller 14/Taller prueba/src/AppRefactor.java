public class AppRefactor {
    public static void main(String[] args) {
        double s = 500000;
        boolean iv = true;
        boolean d = true;
        int t = 1;

        double total = s;

        if (s <= 0) {
            System.out.println("Total: 0");
            return;
        }

        if (d) {
            if (t == 1) {
                total = total - (total * 0.20);
            } else if (t == 2) {
                total = total - (total * 0.10);
            } else {
                total = total - (total * 0.05);
            }
        }

        if (iv) {
            total = total + (total * 0.19);
        }

        total = Math.round(total * 100.0) / 100.0;

        System.out.println("Total: " + total);
    }
}