package model;

public class Envio {
    private String codigo;
    private double pesoKg;

    public Envio(String codigo, double pesoKg) {
        if (codigo == null || codigo.isEmpty()) {
            throw new IllegalArgumentException("Código no válido");
        }
        if (pesoKg <= 0) {
            throw new IllegalArgumentException("Peso debe ser mayor a 0");
        }
        this.codigo = codigo;
        this.pesoKg = pesoKg;
    }

    public String getCodigo() { return codigo; }
    public double getPesoKg() { return pesoKg; }

    public void setPesoKg(double pesoKg) {
        if (pesoKg > 0) this.pesoKg = pesoKg;
    }

    public double calcularCosto() {
        return 0;
    }

    public void resumen() {
        System.out.println("Código: " + codigo +
                " | Peso: " + pesoKg +
                " kg | Costo: $" + calcularCosto());
    }
}
