package App;

import java.util.ArrayList;
import java.util.List;
import model.*;

public class App {
    public static void main(String[] args) {

        List<Envio> envios = new ArrayList<>();

        envios.add(new EnvioEstandar("E001", 2.0));
        envios.add(new EnvioExpress("E002", 1.5));
        envios.add(new EnvioInternacional("E003", 3.0, "México"));

        double total = 0;

        System.out.println("=== ENVÍOS ===\n");

        for (Envio e : envios) {
            e.resumen();
            total += e.calcularCosto();
        }

        System.out.println("\nTotal a pagar: $" + total);
    }
}
