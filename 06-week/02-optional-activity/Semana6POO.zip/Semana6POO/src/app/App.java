package app;

import model.Persona;
import model.Docente;
import model.Administrativo;

public class App {

    public static void main(String[] args) {

        try {
        
            Persona p = new Persona("152", "Danna", "danna@corhuila.edu.co");

            Docente d = new Docente("940", "Jesus", "jesus@corhuila.edu.co", "Programación orientada a objetos");

            Administrativo a = new Administrativo("462", "Óscar", "oscar@corhuila.edu.co", "Rector");

            System.out.println("___ PERSONA ___");
            System.out.println(p.ficha());

            System.out.println("\n___ DOCENTE ___");
            System.out.println(d.fichaDocente());

            System.out.println("\n___ ADMINISTRATIVO ___");
            System.out.println(a.fichaAdministrativo());

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}