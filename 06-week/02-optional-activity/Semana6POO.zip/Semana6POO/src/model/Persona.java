package model;

public class Persona {

    private String documento;
    private String nombre;
    private String correo;

    public Persona(String documento, String nombre, String correo) {
        setDocumento(documento);
        setNombre(nombre);
        setCorreo(correo);
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        if (documento == null || documento.isEmpty()) {
            throw new IllegalArgumentException("Ey-..Documento no puede estar vacío");
        }
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("Ey-..Nombre no puede estar vacío");
        }
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        if (correo == null || !correo.contains("@")) {
            throw new IllegalArgumentException("Ups-..Correo inválido");
        }
        this.correo = correo;
    }

    public String ficha() {
        return "Documento: " + documento +
               "\nNombre: " + nombre +
               "\nCorreo: " + correo;
    }
}