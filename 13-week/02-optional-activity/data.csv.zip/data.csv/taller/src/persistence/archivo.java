package persistence;

import model.Producto;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class archivo {

    private final Path ruta;

    public archivo(String rutaRelativa) {
        this.ruta = Paths.get(rutaRelativa);
    }

    private void asegurarDirectorio() throws IOException {

        Path carpeta = ruta.getParent();

        if (carpeta != null && !Files.exists(carpeta)) {
            Files.createDirectories(carpeta);
        }
    }

    public void guardar(List<Producto> productos) throws IOException {

        asegurarDirectorio();

        List<String> lineas = new ArrayList<>();

        for (Producto p : productos) {
            lineas.add(p.toCsvLine());
        }

        Files.write(
                ruta,
                lineas,
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING
        );
    }

    public List<Producto> cargar() throws IOException {

        List<Producto> productos = new ArrayList<>();

        if (!Files.exists(ruta)) {
            return productos;
        }

        List<String> lineas = Files.readAllLines(ruta);

        for (String linea : lineas) {

            if (linea.trim().isEmpty()) {
                continue;
            }

            productos.add(Producto.fromCsvLine(linea));
        }

        return productos;
    }
}