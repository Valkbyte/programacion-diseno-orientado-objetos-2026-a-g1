package app;

import model.Producto;
import persistence.archivo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        archivo archivo =
                new archivo("data/productos.csv");

        List<Producto> productos;

        try {

            productos = archivo.cargar();

            System.out.println("=== PRODUCTOS CARGADOS ===");

            if (productos.isEmpty()) {
                System.out.println("No hay productos guardados.");
            } else {

                for (Producto p : productos) {
                    System.out.println(p);
                }
            }

            System.out.println("\n=== AGREGAR PRODUCTO ===");

            System.out.print("Código: ");
            String codigo = sc.nextLine();

            System.out.print("Nombre: ");
            String nombre = sc.nextLine();

            System.out.print("Precio: ");
            double precio = sc.nextDouble();

            Producto nuevo = new Producto(codigo, nombre, precio);

            productos.add(nuevo);

            archivo.guardar(productos);

            System.out.println("\nProducto guardado correctamente.");

            System.out.println("\n=== LISTA FINAL ===");

            for (Producto p : productos) {
                System.out.println(p);
            }

        } catch (IOException ex) {

            System.out.println("Error de archivo: "
                    + ex.getMessage());

        } catch (Exception ex) {

            System.out.println("Error: "
                    + ex.getMessage());
        }

        sc.close();
    }
}