package model;

public class Producto {

    private String codigo;
    private String nombre;
    private double precio;

    public Producto(String codigo, String nombre, double precio) {

        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("Código inválido");
        }

        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("Nombre inválido");
        }

        if (precio <= 0) {
            throw new IllegalArgumentException("Precio inválido");
        }

        this.codigo = codigo.trim().toUpperCase();
        this.nombre = nombre.trim();
        this.precio = precio;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public String toCsvLine() {
        return codigo + "," + nombre + "," + precio;
    }

    public static Producto fromCsvLine(String line) {

        String[] parts = line.split(",");

        if (parts.length != 3) {
            throw new IllegalArgumentException("Línea inválida");
        }

        String codigo = parts[0].trim();
        String nombre = parts[1].trim();
        double precio = Double.parseDouble(parts[2].trim());

        return new Producto(codigo, nombre, precio);
    }

    @Override
    public String toString() {
        return "Código: " + codigo +
                " | Nombre: " + nombre +
                " | Precio: $" + precio;
    }
}