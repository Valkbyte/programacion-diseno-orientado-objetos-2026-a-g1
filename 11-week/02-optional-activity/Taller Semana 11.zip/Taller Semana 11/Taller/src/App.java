public class App {

    public static void main(String[] args) {

        Inventario inventario = new Inventario();

        try {

            Producto p1 = new Producto("001", "Sensor", 15000);
            inventario.agregarProducto(p1);

        } catch (IllegalArgumentException | ProductoDuplicadoException e) {

            System.out.println("Error: " + e.getMessage());
        }

        try {

            Producto p2 = new Producto("002", "Mouse", 47000);
            inventario.agregarProducto(p2);

        } catch (IllegalArgumentException | ProductoDuplicadoException e) {

            System.out.println("Error: " + e.getMessage());
        }

        try {

            Producto p3 = new Producto("001", "Monitor", 950000);
            inventario.agregarProducto(p3);

        } catch (IllegalArgumentException | ProductoDuplicadoException e) {

            System.out.println("Error controlado: " + e.getMessage());
        }

        try {

            Producto p4 = new Producto("004", "Laptop", -500000);
            inventario.agregarProducto(p4);

        } catch (IllegalArgumentException | ProductoDuplicadoException e) {

            System.out.println("Error controlado: " + e.getMessage());
        }

        inventario.listar();

        System.out.println("\n¡Gracias por usar el sistema de inventario!");
    }
}