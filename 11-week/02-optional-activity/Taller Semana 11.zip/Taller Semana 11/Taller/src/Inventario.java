import java.util.ArrayList;
import java.util.List;

public class Inventario {

    private List<Producto> productos;

    public Inventario() {
        productos = new ArrayList<>();
    }

    public void agregarProducto(Producto p) {

        for (Producto producto : productos) {

            if (producto.getCodigo().equalsIgnoreCase(p.getCodigo())) {
                throw new ProductoDuplicadoException(p.getCodigo());
            }
        }

        productos.add(p);
        System.out.println("Producto agregado correctamente.");
    }

    public void listar() {

        System.out.println("\n===== TU INVENTARIO =====");

        if (productos.isEmpty()) {
            System.out.println("No hay productos registrados.");
            return;
        }

        for (Producto p : productos) {
            System.out.println(p);
        }
    }
}
