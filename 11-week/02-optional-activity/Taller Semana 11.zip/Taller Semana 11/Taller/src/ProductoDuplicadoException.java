public class ProductoDuplicadoException extends RuntimeException {

    public ProductoDuplicadoException(String codigo) {
        super("Heeyyy ya hay un producto con el código " + codigo);
    }
}